import { PrismaClient } from "@prisma/client";

const prisma = PrismaClient();
const getUserService = async () => {

    const users = prisma.users.findMany();

    return users;
};

export { getUserService };